#ifndef INPUT_H
#define INPUT_H

#include "Core.h"

void keyCallback(GLFWwindow *, int, int, int, int);
//void cursorPosCallback(GLFWwindow *, double, double);
//void mouseButtonCallback(GLFWwindow *, int, int, int);
//void scrollCallback(GLFWwindow *, double, double);
//bool checkForHits();
//
#endif
